import React from 'react';
import './App.css';
import { Container } from 'semantic-ui-react';

import {BrowserRouter, Route} from 'react-router-dom'

import PostProperty from './PostProperty/PostProperty';
import NavBar from './UI/NavBar';
import ListProperty from "./ListProperty/ListProperty";
import PropertyDisplay from './ListProperty/Property/PropertyDisplay/PropertyDisplay';

function App() {
  return (
    <div className="App">
        <NavBar/>
        <Container>
            <BrowserRouter>
                <Route path="/post-property" ><PostProperty/></Route>
                <Route path="/list-properties" component={ListProperty} />
                <Route path="/property-display" component={PropertyDisplay} />
            </BrowserRouter>
        </Container>
    </div>
  );
}

export default App;

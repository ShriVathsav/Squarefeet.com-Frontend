import React, { useState } from 'react'
import { Menu, Segment, Container } from 'semantic-ui-react'

const NavBar = () => {
    const [activeItem, setActiveItem] = useState("home");

    const handleItemClick = (e, { name }) => setActiveItem(name);

        return (
            <Segment inverted style={{marginBottom: 0}}>
                <Menu inverted pointing secondary>
                    <Container>
                    <Menu.Item
                        name='home'
                        active={activeItem === 'home'}
                        onClick={handleItemClick}
                    />
                    <Menu.Item
                        name='messages'
                        active={activeItem === 'messages'}
                        onClick={handleItemClick}
                    />
                    <Menu.Item
                        name='friends'
                        active={activeItem === 'friends'}
                        onClick={handleItemClick}
                    />
            </Container>
                </Menu>
            </Segment>
        )
}

export default NavBar;
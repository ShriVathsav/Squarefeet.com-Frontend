import React, {useState} from 'react';
import { Grid } from 'semantic-ui-react';
import PropertyCard from "./Property/PropertyCard";
import Filters from "./Filters/Filters";

const ListProperty = (props) => {

    const obj = [
        {
            id: 1,
            bedrooms: 10,
            propertyType: "Residential Apartment",
            locality: "delhi",
            superBuiltUpArea: 2000,
            bathrooms: 6,
            personDetail: "owner"
        },
        {
            id: 2,
            bedrooms: 10,
            propertyType: "Residential Apartment",
            locality: "delhi",
            superBuiltUpArea: 2000,
            bathrooms: 6,
            personDetail: "owner"
        }
    ]

    const [propertyList, setPropertyList] = useState(obj);

    return(
        <Grid columns={2}>
            <Grid.Column mobile={16} tablet={16} computer={4}>
                <Filters/>
            </Grid.Column>
            <Grid.Column mobile={16} tablet={16} computer={12}>
                <PropertyCard/>
            </Grid.Column>
        </Grid>
    )
}

export default ListProperty;
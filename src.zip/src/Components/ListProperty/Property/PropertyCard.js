import React, {useState, Fragment, useEffect} from 'react';
import axios from 'axios'

import {Card, Image, Icon, Grid, Segment, Button, Header, Feed, Comment, Form, Item} from 'semantic-ui-react';
import compass2 from "../../Icons/compass.svg";
import bathroom from "../../Icons/bath.svg";
import price from "../../Icons/money.svg";
import area from "../../Icons/floor-plan.svg";
import age from "../../Icons/calendar.svg";
import bedroom from "../../Icons/bed.svg";
import favoriteActive from "../../Icons/favorite-active.svg";
import favorite from "../../Icons/favorite.svg";
import postedOn from "../../Icons/sticky-notes.svg";

import propertyPrice from "../../ColorIcons/propertyPrice.svg";
import superArea from "../../ColorIcons/superBuiltUpArea.svg";
import room from "../../ColorIcons/bedroom.svg";
import propertyType from "../../ColorIcons/propertyType.svg";
import floors from "../../ColorIcons/stairs.svg";
import propertyAge from "../../ColorIcons/propertyAge.svg";
import facing from "../../ColorIcons/facing.svg";

import postedBy1 from "../../ColorIcons/clip.svg";
import postedBy2 from "../../ColorIcons/share-post.svg";
import Axios from 'axios';


const generator = [
    {id: 1, icon: propertyPrice, label: "Price", value: "1.25 Cr"},
    {id: 2, icon: propertyType, label: "Property ", value: "Residential Apartment"},
    {id: 3, icon: superArea, label: "Super Area", value: "2000 sq.ft."},
    {id: 4, icon: room, label: "Configuration", value: "10 BHK"},
    {id: 5, icon: floors, label: "Floors", value: "7th out of 10"},
    {id: 6, icon: propertyAge, label: "Property Age", value: "5 Years"},
]

const PropertyCard = (props) => {
    const [shortList, setShortList] = useState(false);

    return(
        <Fragment>
            <Card fluid raised>
                <Card.Content>
                <Grid>
                    <Grid.Row>
                        <Grid.Column mobile={16} tablet={8} computer={6} stretched>
                            <Segment fluid></Segment>
                            {/*<Image src={"https://paranoidandroid.co/assets/wallpapers/2018/submerged_desktop_thumb.jpg"} size='massive' fluid/>*/}
                        </Grid.Column>
                        <Grid.Column mobile={16} tablet={8} computer={10}>
                            <Grid>
                            <Grid.Row>
                                <Grid.Column>
                                    <Header>10 Bedroom Independent House in Delhi Central</Header>
                                </Grid.Column>
                            </Grid.Row>
                            </Grid>
                            <Grid>
                                {generator.map(item =>
                                    <Grid.Column key={item.id} width={5}>
                                        <Comment.Group>
                                            <Comment>
                                                <Comment.Avatar as='a' src={item.icon} />
                                                <Comment.Content>
                                                    <Comment.Text><Header as="h4">{item.value}</Header></Comment.Text>
                                                    <Comment.Text>{item.label}</Comment.Text>
                                                </Comment.Content>
                                            </Comment>
                                        </Comment.Group>
                                    </Grid.Column>
                                )}
                            </Grid>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
            </Card.Content>
            <Card.Content extra>
                <Grid columns={2}>
                    <Grid.Column>
                        <Comment.Group>
                            <Comment>
                                <Comment.Avatar src={postedBy1} />
                                <Comment.Content>
                                    <Comment.Actions>
                                        <Comment.Action>Posted on May 23, 2020</Comment.Action>
                                    </Comment.Actions>
                                    <Comment.Text><Header as="h3">Individual Consultant</Header></Comment.Text>
                                </Comment.Content>
                            </Comment>
                        </Comment.Group>
                    </Grid.Column>
                    <Grid.Column>
                        <Button floated="right" size='large' color="blue">View Owner Details</Button>
                        <Image src={shortList? favoriteActive : favorite} style={{"margin-right": 20, "cursor": "pointer"}}
                            onClick={() => setShortList(prev => !prev)} floated="right" size="mini"/>
                    </Grid.Column>
                    </Grid>
                </Card.Content>
            </Card>


        <Card fluid raised>
            <Card.Content>
            <Grid>
                <Grid.Row>
                    <Grid.Column mobile={16} tablet={8} computer={6} stretched>
                        <Segment fluid></Segment>
                        {/*<Image src={"https://paranoidandroid.co/assets/wallpapers/2018/submerged_desktop_thumb.jpg"} size='massive' fluid/>*/}
                    </Grid.Column>
                    <Grid.Column mobile={16} tablet={8} computer={10}>
                        <Grid>
                        <Grid.Row>
                            <Grid.Column>
                                <Header>10 Bedroom Independent House in Delhi Central</Header>
                            </Grid.Column>
                        </Grid.Row>
                        </Grid>
                        <Grid columns="equal">
                        <Grid.Row>
                            <Grid.Column>
                                <Comment.Group>
                                    <Comment>
                                        <Comment.Avatar as='a' src={price} />
                                        <Comment.Content>
                                            <Comment.Text><Header>1.25 Cr</Header></Comment.Text>
                                            <Comment.Text>Price</Comment.Text>
                                        </Comment.Content>
                                    </Comment>
                                </Comment.Group>
                            </Grid.Column>
                            <Grid.Column>
                                <Comment.Group>
                                    <Comment>
                                        <Comment.Avatar as='a' src={area} />
                                        <Comment.Content>
                                            <Comment.Text><Header>2000 sq.ft.</Header></Comment.Text>
                                            <Comment.Text>Area</Comment.Text>
                                        </Comment.Content>
                                    </Comment>
                                </Comment.Group>
                            </Grid.Column>
                            <Grid.Column>
                                <Comment.Group>
                                    <Comment>
                                        <Comment.Avatar as='a' src={bedroom} />
                                        <Comment.Content>
                                            <Comment.Text><Header>10 BHK</Header></Comment.Text>
                                            <Comment.Text>Rooms</Comment.Text>
                                        </Comment.Content>
                                    </Comment>
                                </Comment.Group>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row>
                            <Grid.Column>
                                <Comment.Group>
                                    <Comment>
                                        <Comment.Avatar as='a' src={compass2} />
                                        <Comment.Content>
                                            <Comment.Text><Header>South</Header></Comment.Text>
                                            <Comment.Text>Facing</Comment.Text>
                                        </Comment.Content>
                                    </Comment>
                                </Comment.Group>
                            </Grid.Column>
                            <Grid.Column><Comment.Group>
                                <Comment>
                                    <Comment.Avatar as='a' src={age} />
                                    <Comment.Content>
                                        <Comment.Text><Header>5 Years</Header></Comment.Text>
                                        <Comment.Text>Age of Property</Comment.Text>
                                    </Comment.Content>
                                </Comment>
                            </Comment.Group></Grid.Column>
                            <Grid.Column><Comment.Group>
                                <Comment>
                                    <Comment.Avatar as='a' src={bathroom} />
                                    <Comment.Content>
                                        <Comment.Text><Header>5</Header></Comment.Text>
                                        <Comment.Text>Bathrooms</Comment.Text>
                                    </Comment.Content>
                                </Comment>
                            </Comment.Group></Grid.Column>
                        </Grid.Row>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
            </Card.Content>
            <Card.Content extra>
                <Grid columns={2}>
                    <Grid.Column>
                        <Comment.Group>
                            <Comment>
                                <Comment.Avatar src={postedOn} />
                                <Comment.Content>
                                    <Comment.Actions>
                                        <Comment.Action>Posted on May 23, 2020</Comment.Action>
                                    </Comment.Actions>
                                    <Comment.Text><Header as="h3">Individual Consultant</Header></Comment.Text>
                                </Comment.Content>
                            </Comment>
                        </Comment.Group>
                    </Grid.Column>
                    <Grid.Column>
                <Button floated="right" size='large' color="blue">View Owner Details</Button>
                <Image size="mini" src={favorite} style={{"margin-right": 20, "cursor": "pointer"}} floated="right"/>
                </Grid.Column></Grid>
            </Card.Content>
        </Card>
        </Fragment>
    )
}

export default PropertyCard;
import React, {useState} from 'react';

const DisplayFeatures = (props) => {
    return(
        <div>DisplayFeatures</div>
    )
}

export default DisplayFeatures;
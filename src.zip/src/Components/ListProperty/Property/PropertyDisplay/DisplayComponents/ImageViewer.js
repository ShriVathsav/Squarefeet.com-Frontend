import React, {useState, Fragment, useEffect} from 'react';
import { Segment, Menu, Header, Icon, Image, Grid, Button } from 'semantic-ui-react';
import rightArrow from '../../../../Icons/next2.svg'
import leftArrow from '../../../../Icons/previous2.svg'

const sliderSegmentStyle = {
    width:60, position: "absolute", zIndex: 1,top: 0, bottom: 0, margin: 0, cursor: "pointer", alignItems: "center",
    border: "none", boxShadow: "none", borderRadius: 0, height: "100%", display: "flex", justifyContent: "center"
}

const mainSegmentStyle = {
    overflow: "hidden", position: "relative", paddingTop: 0, paddingBottom: 0
}

const ImageViewer = (props) => {

    const {propertiesProps, propertyProps, prevProperty, nextProperty} = props;

    const [properties, setProperties] = propertiesProps
    const [property, setProperty] = propertyProps
    const [multiplier, setMultiplier] = useState(0)
    const [leadIndex, setLeadIndex] = useState(0)
    const [trailIndex, setTrailIndex] = useState(0)
    const [leadIndexFull, setLeadIndexFull] = useState(true)
    const [divWidth, setDivWidth] = useState(0)
    const [noOfThumbs, setNoOfThumbs] = useState(0)

    let wid
    let noOfThumbsInit
    let trailIndexInit

    useEffect(() => {
        wid = document.getElementById("mydiv").offsetWidth -120
        noOfThumbsInit = Math.ceil(wid/150)
    })

    useEffect(() => {        
        setDivWidth(wid)
        setNoOfThumbs(noOfThumbsInit)
    }, [])

    useEffect(() => {
        if(property.index === trailIndex+noOfThumbs-1 && leadIndexFull){
            setMultiplier((prevMul) => prevMul - (noOfThumbs * 150 - wid))
            setLeadIndexFull(false)
        }
        else if(property.index === leadIndex && leadIndexFull === true){
            return;
        }
        else if(property.index === leadIndex && leadIndexFull === false){
            setMultiplier((prevMul) => prevMul + (noOfThumbs * 150 - wid))
            setLeadIndexFull(true)
        }
        else if(property.index > trailIndex+noOfThumbs-1 && trailIndex+noOfThumbs <= properties.length-1){
            setMultiplier((-150 * (property.index-noOfThumbs+1)- (noOfThumbs * 150 - wid)))
            setLeadIndexFull(false)
            setLeadIndex(property.index-noOfThumbs+1)
            setTrailIndex(property.index-noOfThumbs+1)
        }
        else if(property.index < leadIndex && leadIndex !== 0){
            setMultiplier(-150 * property.index)
            setLeadIndexFull(true)
            setLeadIndex(property.index)
            setTrailIndex(property.index)
        }
    }, [property])

    const leftSliderClick = () => {
        if(leadIndex !== 0){
            setLeadIndex(prev => prev - 1)
            setTrailIndex(prev => prev - 1)
            setMultiplier((prevMul) => prevMul + 150)
        }
        else if(leadIndex === 0 && leadIndexFull === false){
            setLeadIndexFull(true)
            setMultiplier((prevMul) => {console.log(prevMul + (noOfThumbs * 150 - wid), "left"); return prevMul + (noOfThumbs * 150 - wid);})
        }
    }

    const rightSliderClick = () => {
        if(trailIndex+noOfThumbs <= properties.length-1){
            setLeadIndex(prev => prev  + 1)
            setTrailIndex(prev => prev  + 1)
            setMultiplier((prevMul) => prevMul - 150)
        }
        else if(trailIndex+noOfThumbs === properties.length-1){
            setLeadIndexFull(false)
            setMultiplier((prevMul) => {console.log(prevMul - (noOfThumbs * 150 - wid), "right"); return prevMul - (noOfThumbs * 150 - wid);})
        }
    }

    return(
        <Fragment>            
            <Segment compact style={{...mainSegmentStyle, paddingLeft: 60, paddingRight: 60}} id="mydiv">  
                <Segment style={{...sliderSegmentStyle, left: 0}} onClick={leftSliderClick}>
                    <Image src={leftArrow} />
                </Segment>
                <div style={{display: "flex", justifyContent: "center"}}>
                    <div className="card-slider" style={{transform: `translateX(${multiplier}px`}}>
                        {
                            properties.map(propertyItem => {
                                let styleArr;
                                styleArr = propertyItem.index !== property.index ? {opacity: 0.5, transform: "scale(0.85)"} :{opacity: 1, transform: "scale(1)"}
                                return <Image src={propertyItem.picture} size="small" onClick={() => setProperty(propertyItem)} key={propertyItem.index}
                                    style={{...styleArr, cursor: "pointer", transition: "opacity 300ms linear, transform 300ms cubic-bezier(0.455, 0.03, 0.515, 0.955)"}}/>
                            })
                        }
                    </div> 
                </div>                             
                <Segment style={{...sliderSegmentStyle, right:0}} onClick={rightSliderClick}>
                    <Image src={rightArrow} />
                </Segment>          
            </Segment>
        </Fragment>
    )
}

export default ImageViewer;
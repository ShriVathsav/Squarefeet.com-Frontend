import React, {useState} from 'react';
import {Grid, Menu} from 'semantic-ui-react'

const MenuTab = () => {

    const [activeItem, setActiveItem] = useState("Property Details");

    const handleItemClick = (e, { name }) => setActiveItem(name);

    return(
        <Menu pointing secondary>
            <Menu.Item
                name='Property Details'
                active={activeItem === 'Property Details'}
                onClick={handleItemClick}
            />
            <Menu.Item
                name='Features'
                active={activeItem === 'Features'}
                onClick={handleItemClick}
            />
            <Menu.Item
                name='Location Details'
                active={activeItem === 'Location Details'}
                onClick={handleItemClick}
            />
            <Menu.Item
                name='Owner Details'
                active={activeItem === 'Owner Details'}
                onClick={handleItemClick}
            />
            <Menu.Menu position='right'>
                <Menu.Item
                    name='logout'
                    active={activeItem === 'logout'}
                    onClick={handleItemClick}
                />
            </Menu.Menu>
        </Menu>
    )
}

export default MenuTab;
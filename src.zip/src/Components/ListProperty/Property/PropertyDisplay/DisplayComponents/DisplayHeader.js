import React, {useState} from 'react';
import {Button, Grid, Header, Icon, Segment, Label, Image} from "semantic-ui-react";
import MenuTab from "./MenuTab";
import shortlist from '../../../../Icons/DisplayPropertyIcons/shortlist.svg'
import shortlist2 from '../../../../Icons/DisplayPropertyIcons/shortlist-2.svg'

const DisplayHeader = (props) => {

    const [shortList, setShortList] = props.shortListProps

    const stack = () => {
        if (window.matchMedia("(max-width: 767px)").matches) {
            return true
        } else {
            return false
        }
    } 

    return(
        <Segment padded style={{margin: 0, paddingBottom: 0}} id="header-segment">
            <Grid>
                <Grid.Column mobile={6} tablet={5} computer={4}>
                    <Header>
                    {!stack() && <Icon name="rupee sign" />}
                        <Header.Content id="display-header-main">
                        {stack() && <span>&#x20B9;</span>} 2.5 Cr
                            <Header.Subheader id="subheader">@ 27,000 per sq.ft.</Header.Subheader>
                        </Header.Content>
                    </Header>
                </Grid.Column>
                <Grid.Column mobile={10} tablet={5} computer={4}>
                    <Header as='h3' id="display-header">
                        {!stack() ? <span>10 Bedrooms 3 Bathrooms</span> : <span>10BHK 3Bath</span>}
                        <Header.Subheader id="subheader">
                            Independent House/Villa for Sale
                        </Header.Subheader>
                    </Header>
                </Grid.Column>     
                {!stack() &&
                    <Grid.Column mobile={2} tablet={6} computer={8} verticalAlign="middle">                    
                        <Button basic={!shortList} color="red" floated="right" style={{borderRadius: 0}}
                            onClick={() => setShortList(prev => !prev)} size="large">
                            <Icon name={shortList ? "star" : "star outline"} color={shortList && "yellow"} style={{zIndex: 2}}/>
                            {shortList ? "Shortlisted" : "Shortlist"}
                        </Button>
                    </Grid.Column>
                }
            </Grid>
            <div style={{overflow: "hidden"}}>
            <MenuTab/></div>
        </Segment>
    )
}

export default DisplayHeader;
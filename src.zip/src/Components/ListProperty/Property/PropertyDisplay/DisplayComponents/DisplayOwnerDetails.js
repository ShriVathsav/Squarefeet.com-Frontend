import React, {useState} from 'react';

const DisplayOwnerDetails = (props) => {
    return(
        <div>DisplayOwnerDetails</div>
    )
}

export default DisplayOwnerDetails;
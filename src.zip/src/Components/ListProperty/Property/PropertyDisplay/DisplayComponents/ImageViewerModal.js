import React, {useState, useEffect, Fragment} from 'react'
import { Button, Header, Icon, Modal, Segment, Image, Popup, Label } from 'semantic-ui-react'
import data from "./Data";
import ImageViewer from './ImageViewer'
import leftArrow from '../../../../Icons/leftArrow3.svg'
import rightArrow from '../../../../Icons/rightArrow3.svg'
import delete2 from '../../../../Icons/delete2.svg'

import shortlist from '../../../../Icons/DisplayPropertyIcons/shortlist.svg'
import shortlist2 from '../../../../Icons/DisplayPropertyIcons/shortlist-2.svg' 

const imageArrowStyle = {
  cursor: "pointer", position: "absolute", top: 230
}

const ImageViewerModal = (props) => {
  const [open, setOpen] = useState(false)
  const propertiesState = useState(data.properties)
  const propertyState = useState(data.properties[0])

  const [shortList, setShortList] = props.shortListProps

  const [property, setProperty] = propertyState
  const [properties, setProperties] = propertiesState

  
  const nextProperty = () => {
    let newIndex;
    if(property.index !== properties.length-1){
        newIndex = property.index+1;
        setProperty(properties[newIndex])
    }
  }

  const prevProperty = () => {
      let newIndex;
      if(property.index !== 0){
          newIndex = property.index-1;
          setProperty(properties[newIndex])
      }
  }

  const segment2 = (
    <Segment id="display-property-image" 
          style={{ maxWidth: 430, cursor: "pointer", paddingRight: 3, position: "relative"}} >
      <div style={{float: "right"}}>
          <div style={{display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center"}}>
            <Image src={shortList ? shortlist2 : shortlist}  size="mini" style={{marginBottom: 5, marginRight: !shortList && 15.53}}
                onClick={(e) => {e.stopPropagation(); setShortList(prev => !prev);}}/>
            {shortList && <Label color='red' horizontal style={{margin: 0, opacity: 0.6, fontSize: 10}}>Shortlisted</Label>}
          </div>
      </div>
      <Image src='https://react.semantic-ui.com/images/wireframe/image.png' id="shortlist-icon" 
        id="display-property-image" style={{cursor: "pointer"}}/>
    </Segment>
  )

  const segment = (
    <Fragment>
      <Image id="display-property-image" src='https://react.semantic-ui.com/images/wireframe/image.png'
          style={{ maxWidth: 430, cursor: "pointer"}} />
      <div style={{float: "right"}} id="shortlist-icon">
          <div style={{display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center"}}>
            <Image src={shortList ? shortlist2 : shortlist}  size="mini" style={{marginBottom: 5, marginRight: !shortList && 15.53}}
                onClick={(e) => {e.stopPropagation(); setShortList(prev => !prev);}}/>
            {shortList && <Label color='red' horizontal style={{margin: 0, opacity: 0.6, fontSize: 10}}>Shortlisted</Label>}
          </div>
      </div>
      </Fragment>
  )

  const dispImage = (
      <Image
          fluid rounded style={{cursor: "pointer"}}
          label={{
            as: 'a',
            color: shortList ? "red" : "orange",
            content: shortList ? "Shortlisted" : 'Shortlist',
            icon: 'star',
            size: "medium",
            ribbon: true,
            onClick: (e) => {e.stopPropagation(); setShortList(prev => !prev);}
          }}
          src='https://react.semantic-ui.com/images/wireframe/image.png'
      />

  )

  

  return (
    <Modal basic onClose={() => setOpen(false)} onOpen={() => setOpen(true)} open={open} closeOnDimmerClick={false}
          size='fullscreen' trigger={dispImage} 
          style={{left: 0, right: 0, width: "100%", position: "relative"}}>
        <Image src={leftArrow} size="mini" style={{...imageArrowStyle, left: 0}} onClick={prevProperty}/>
        <Image src={rightArrow} size="mini" style={{...imageArrowStyle, right: 0}} onClick={nextProperty}/>
        <Image src={delete2} size="mini" style={{position: "absolute", right: 0, top: 0, cursor: "pointer"}} onClick={() => {setProperty(data.properties[0]); setOpen(false)}}/>
        <Modal.Content image style={{paddingTop: 0, display: "flex", justifyContent: "center"}}>
            <Image src={propertyState[0].picture} size="big"/>
        </Modal.Content>
        <Modal.Content style={{ display: "flex", justifyContent: "center"}}>
            <ImageViewer propertiesProps={propertiesState} propertyProps={propertyState} prevProperty={prevProperty} nextProperty={nextProperty}/>
        </Modal.Content>
    </Modal>
  )
}

export default ImageViewerModal;
import React, {useState} from 'react';

const DisplayLocationDetails = (props) => {
    return(
        <div>DisplayLocationDetails</div>
    )
}

export default DisplayLocationDetails;
import React, {Fragment, useState} from 'react';
import { Segment, Menu, Header, Icon, Image, Grid, Button } from 'semantic-ui-react';
import DisplayHeader from './DisplayComponents/DisplayHeader';
import DisplayPropertyDetails from "./DisplayComponents/DisplayPropertyDetails";
import ImageViewer from './DisplayComponents/ImageViewer';


const PropertyDisplay = (props) => {

    const shortListProps = useState(false)

    return(
        <Fragment>
            <DisplayHeader shortListProps={shortListProps}/>
            <DisplayPropertyDetails shortListProps={shortListProps}/>
        </Fragment>
    )
}

export default PropertyDisplay;
import React,{useState, Fragment, useEffect} from 'react';

import axios from 'axios'

import wifi2 from '../Icons/FeatureIcons/wifi-2.svg';
import gym2 from '../Icons/FeatureIcons/gym-2.svg';
import airCondition2 from '../Icons/FeatureIcons/airconditioning-2.svg';
import intercom2 from '../Icons/FeatureIcons/intercom-2.svg';
import security2 from '../Icons/FeatureIcons/security-2.svg';
import pool2 from '../Icons/FeatureIcons/swimming-pool-2.svg';
import park2 from '../Icons/FeatureIcons/park-2.svg';
import fireAlarm2 from '../Icons/FeatureIcons/fire-alarm-2.svg';
import fengShui2 from '../Icons/FeatureIcons/fengshui-2.svg';
import maintenance2 from '../Icons/FeatureIcons/maintenance-2.svg';
import cctv2 from '../Icons/FeatureIcons/cctv-2.svg';

import wifi from '../Icons/FeatureIcons/wifi.svg';
import gym from '../Icons/FeatureIcons/gym.svg';
import airCondition from '../Icons/FeatureIcons/airconditioning.svg';
import intercom from '../Icons/FeatureIcons/intercom.svg';
import security from '../Icons/FeatureIcons/security.svg';
import pool from '../Icons/FeatureIcons/swimming-pool.svg';
import park from '../Icons/FeatureIcons/park.svg';
import fireAlarm from '../Icons/FeatureIcons/fire-alarm.svg';
import fengShui from '../Icons/FeatureIcons/fengshui.svg';
import maintenance from '../Icons/FeatureIcons/maintenance.svg';
import cctv from '../Icons/FeatureIcons/cctv.svg';

import BasicDetails from './SubForms/BasicDetails';
import Features from './SubForms/Features';
import Location from './SubForms/Location';
import Pricing from './SubForms/Pricing';
import PropertyDetails from './SubForms/PropertyDetails';
import Axios from 'axios';

const MainForm = (props) => {

    // BASIC DETAILS STATE MANAGEMENT
    const youAreProp = useState("");
    const listPropertyForProp = useState("");
    const propertyTypeProp = useState("");
    const apartmentTypeProp = useState("");
    const basicDetailsValidProp = props.basicDetailsValidProp
    const basicDetailsProps = {youAreProp, listPropertyForProp, propertyTypeProp, apartmentTypeProp, basicDetailsValidProp, handleClick: props.handleClick}


    // LOCATION STATE MANAGEMENT
    const houseNoProp = useState("");
    const streetNameProp = useState("");
    const localityProp = useState("");
    const landmarkProp = useState("");
    const cityProp = useState("");
    const projectNameProp = useState("");
    const locationValidProp = props.locationValidProp
    const locationProps = {houseNoProp, streetNameProp, localityProp, cityProp, 
            landmarkProp, projectNameProp, locationValidProp, handleClick: props.handleClick}

    // PROPERTY DETAILS STATE MANAGEMENT
    const superBuiltUpAreaProp = useState("");
    const builtUpAreaProp = useState("");
    const carpetAreaProp = useState("");
    const bedroomsProp = useState("");
    const bathroomsProp = useState("");
    const balconiesProp = useState("");
    const otherRoomsProp = useState([]);
    const furnishingDetProp = useState("");
    const furnishingItemsProp = useState([]);
    const totalFloorProp = useState("");
    const propertyOnFloorProp = useState("");
    const reservedParkingProp = useState(false);
    const closedParkingProp = useState("");
    const openParkingProp = useState("");
    const propertyAgeProp = useState("");
    const availabilityProp = useState("");
    const possessionByProp = useState("");
    const undividedShareProp = useState("");
    const numberOfFlatsProp = useState("");
    const elevatorProp = useState(false);
    const plotAreaProp = useState("");
    const floorsAllowedProp = useState("");
    const propertyDetailsValidProp = props.propertyDetailsValidProp
    const propertyDetailsProps = {superBuiltUpAreaProp, builtUpAreaProp, carpetAreaProp, bedroomsProp, bathroomsProp,
        balconiesProp, otherRoomsProp, furnishingDetProp,furnishingItemsProp, totalFloorProp, propertyOnFloorProp, reservedParkingProp,
        closedParkingProp, openParkingProp, propertyAgeProp, availabilityProp, possessionByProp, undividedShareProp,
        numberOfFlatsProp, elevatorProp,plotAreaProp, floorsAllowedProp, propertyDetailsValidProp, propertyTypeProps: propertyTypeProp[0],
        listPropertyForProps: listPropertyForProp[0], handleClick: props.handleClick}


    // PRICING STATE MANAGEMENT
    const ownerShipProp = useState("");
    const expectedPriceProp = useState("");
    const allPricesInclusiveProp = useState(false);
    const priceNegotiableProp = useState(false);
    const bookingAdvanceProp = useState("");
    const maintenanceChargesProp = useState("");
    const expectedRentalProp = useState("");
    const brokerageProp = useState("");
    const pricingValidProp = props.pricingValidProp
    const pricingProps = {ownerShipProp, expectedPriceProp, allPricesInclusiveProp, priceNegotiableProp,
        bookingAdvanceProp, maintenanceChargesProp, expectedRentalProp, pricingValidProp, propertyTypeProps: propertyTypeProp[0],
        listPropertyForProps: listPropertyForProp[0], youAreProps: youAreProp[0], handleClick: props.handleClick, brokerageProp}


    // FEATURES STATE MANAGEMENT
    const filesProp = useState([]);
    const amenitiesProp = useState([]);
    const moreAmenitiesProp = useState([]);
    const cornerPropertyProp = useState(false);
    const gatedSocietyProp = useState(false);
    const facingProp = useState("");
    const facingRoadProp = useState("");
    const flooringTypeProp = useState("");
    const powerBackupProp = useState("");
    const waterStorageProp = useState("");
    const waterSourceProp = useState("");
    const boundaryWallProp = useState("");
    const overlookingProp = useState("");
    const propertyDescriptionProp = useState("");
    const featuresValidProp = props.featuresValidProp
    const featuresProps = {filesProp, amenitiesProp, moreAmenitiesProp, cornerPropertyProp, gatedSocietyProp,
        facingProp, facingRoadProp, flooringTypeProp, powerBackupProp, waterStorageProp, waterSourceProp,
        overlookingProp, propertyDescriptionProp, featuresValidProp, propertyTypeProps: propertyTypeProp[0],
        listPropertyForProps: listPropertyForProp[0], handleClick: props.handleClick, boundaryWallProp}



    useEffect(() => {
        const iconGenerator = [
            {id: 0, active: false, icon2: wifi2, icon1: wifi, name: "Wi-Fi Connectivity"}, 
            {id: 1, active: false, icon2: gym2, icon1: gym, name: "Gym / Fitness Centre"},
            {id: 2, active: false, icon2: airCondition2, icon1: airCondition, name: "Centrally Air Conditioned"}, 
            {id: 3, active: false, icon2: intercom2, icon1: intercom, name: "Intercom Facility"},
            {id: 4, active: false, icon2: security2, icon1: security, name: "Security Personnel"}, 
            {id: 5, active: false, icon2: pool2, icon1: pool, name: "Swimming Pool"},
            {id: 6, active: false, icon2: park2, icon1: park, name: "Park"}, 
            {id: 7, active: false, icon2: fireAlarm2, icon1: fireAlarm, name: "Fire Alarm"}, 
            {id: 8, active: false, icon2: cctv2, icon1: cctv, name: "Surveillance"},
            {id: 9, active: false, icon2: fengShui2, icon1: fengShui, name: "Feng Shui / Vaastu Compliant"}, 
            {id: 10, active: false, icon2: maintenance2, icon1: maintenance, name: "Maintenance Staff"}
        ]
        amenitiesProp[1](iconGenerator)
    }, [])

    const propertyFormFields = {
        "property_type": propertyTypeProp[0],
        "apartment_type": apartmentTypeProp[0],
        "poster_designation": youAreProp[0],
        "list_property_for": listPropertyForProp[0],
        "location": "",
        "locality": localityProp[0],
        "city": cityProp[0],
        "landmark": "",
        "street": streetNameProp[0],
        "door_no": houseNoProp[0],
        "super_builtup_area": superBuiltUpAreaProp[0],
        "plot_area": plotAreaProp[0],
        "carpet_area": carpetAreaProp[0],
        "builtup_area": builtUpAreaProp[0],
        "undivided_share": undividedShareProp[0],
        "bedrooms": bedroomsProp[0],
        "bathrooms": bathroomsProp[0],
        "balconies": balconiesProp[0],
        "furnishing": furnishingDetProp[0],
        "total_floors": totalFloorProp[0],
        "property_on_floor": propertyOnFloorProp[0],
        "floors_allowed_for_construction": floorsAllowedProp[0],
        "number_of_flats": numberOfFlatsProp[0],
        "presence_of_elevator": elevatorProp[0],
        "reserved_parking": reservedParkingProp[0],
        "closed_parking": closedParkingProp[0],
        "open_parking": openParkingProp[0],
        "availability": availabilityProp[0],
        "property_age": propertyAgeProp[0],
        "possession_by": possessionByProp[0],
        "ownership": ownerShipProp[0],
        "price": expectedPriceProp[0],
        "booking_advance": bookingAdvanceProp[0],
        "maintenance": maintenanceChargesProp[0],
        "expected_rental": expectedRentalProp[0],
        "all_prices_inclusive": allPricesInclusiveProp[0],
        "price_negotiable": priceNegotiableProp[0],
        "brokerage": brokerageProp[0],
        "water_source": waterSourceProp[0],
        "overlooking": overlookingProp[0],
        "capacity_of_water_storage": waterStorageProp[0],
        "corner_property": cornerPropertyProp[0],
        "gated_society": gatedSocietyProp[0],
        "facing": facingProp[0],
        "width_of_facing_road": facingRoadProp[0],
        "flooring_type": flooringTypeProp[0],
        "power_backup": powerBackupProp[0],
        "property_description": propertyDescriptionProp[0],
        "posting_status": "Active",
        "profile_id": 1
    }

    const formSubmitHandler = () => {
        console.log("YET TO SUBMIT FORM")
        console.log(basicDetailsValidProp[0], locationValidProp[0], propertyDetailsValidProp[0], pricingValidProp[0], featuresValidProp[0])
        if(basicDetailsValidProp[0] && locationValidProp[0] && propertyDetailsValidProp[0] && pricingValidProp[0] && featuresValidProp[0]){
            console.log("SUBMITTING FORM", propertyFormFields)
            axios.post('/properties', propertyFormFields).then(res => console.log(res))
        }
    }

    const renderForm = () => {
        switch(props.stepProps[0]){
            case 1:
                return <BasicDetails {...basicDetailsProps} step={props.stepProps}/>
            case 2:
                return <Location {...locationProps} step={props.stepProps}/>
            case 3:
                return <PropertyDetails {...propertyDetailsProps} step={props.stepProps}/>
            case 4:
                return <Pricing {...pricingProps} step={props.stepProps}/>
            case 5:
                return <Features {...featuresProps} step={props.stepProps} formSubmitHandler={formSubmitHandler}/>
        }
    }

    return(
        <Fragment>
            {renderForm()}
        </Fragment>
    )
}

export default MainForm;
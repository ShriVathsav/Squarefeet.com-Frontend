import React,{useState, useEffect} from 'react';
import {Input, Form, Grid, Dropdown, Radio, Button, Icon, Header, Label} from 'semantic-ui-react';

const ERROR_MESSAGE_INPUT = "This field is mandatory"
const ERROR_MESSAGE_DROPDOWN = "Please select a value"


const ownership = [
    { key: 'm', text: 'Freehold', value: 'Freehold' },
    { key: 'f', text: 'Leasehold', value: 'Leasehold' },
    { key: 'o', text: 'Power of Attorney', value: 'Power of Attorney' },
    { key: 'b', text: 'Cooperative Society', value: 'Cooperative Society' }
];

const maintenance = [
    { key: 'm', text: 'Monthly', value: 'Monthly' },
    { key: 'f', text: 'Annually', value: 'Annually' },
    { key: 'o', text: 'One Time', value: 'One Time' }
];

const negotiableOptions = [
    { key: 'm', text: 'Negotiable', value: "Negotiable" },
    { key: 'f', text: 'Non-Negotiable', value: "Non-Negotiable" }
];


const Pricing = (props) => {
    const [step, setStep] = props.step

    const {ownerShipProp, expectedPriceProp, allPricesInclusiveProp, priceNegotiableProp, brokerageProp, youAreProps,
        bookingAdvanceProp, maintenanceChargesProp, expectedRentalProp, propertyTypeProps, pricingValidProp} = props

    const [ownerShip, setOwnerShip] = ownerShipProp
    const [expectedPrice, setExpectedPrice] = expectedPriceProp
    const [allPricesInclusive, setAllPricesInclusive] = allPricesInclusiveProp
    const [priceNegotiable, setPriceNegotiable] = priceNegotiableProp
    const [bookingAdvance, setBookingAdvance] = bookingAdvanceProp
    const [maintenanceCharges, setMaintenanceCharges] = maintenanceChargesProp
    const [expectedRental, setExpectedRental] = expectedRentalProp
    const [brokerage, setBrokerage] = brokerageProp
    const [pricingValid, setPricingValid] = pricingValidProp

    useEffect(() => console.log(ownerShip, expectedPrice, allPricesInclusive, priceNegotiable,
        bookingAdvance, maintenanceCharges, expectedRental));

    
    const formValid = () => {
        const valid = (ownership !== "" && expectedPrice !== "" && bookingAdvance !== "" && 
            !(propertyTypeProps === "Apartment" && maintenance === "") && (youAreProps === "Broker" ? brokerage !== "": true))
        setPricingValid(valid)
    }

    useEffect(() => formValid())

    return(
        <Form>
            <Header as='h2' textAlign="center">
                <Header.Content>Pricing</Header.Content>
            </Header>
            <Grid>
                    <Grid.Column mobile={16} tablet={8} computer={8}>
                        <Form.Field required>
                            <label>Ownership</label>
                            <Dropdown fluid selection value={ownerShip} options={ownership}
                                placeholder='Ownership' onChange={(event, data) => setOwnerShip(data.value)}
                            />
                            {ownerShip === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                        </Form.Field>
                    </Grid.Column>
                    <Grid.Column mobile={16} tablet={16} computer={16}>
                        <Form.Field required>
                            <label>Expected Price</label>
                            <Input value={expectedPrice} placeholder='Expected price'
                                action={
                                    <Dropdown button basic floating options={negotiableOptions} defaultValue='Negotiable' />
                                }
                                type="number" min="0" icon='rupee sign' iconPosition='left'
                                onChange={(event) => setExpectedPrice(event.target.value)}
                            />
                            {expectedPrice === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_INPUT}</Label>}
                        </Form.Field>
                    </Grid.Column>
                    <Grid.Column mobile={16} tablet={8} computer={8}>
                        <Form.Field required>
                            <label>Booking Advance</label>
                            <Input icon='rupee sign' iconPosition='left' type="number"
                                   placeholder='Booking Advance' value={bookingAdvance}
                                   onChange={(event) => setBookingAdvance(event.target.value)}/>
                            {bookingAdvance === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_INPUT}</Label>}
                        </Form.Field>
                    </Grid.Column>
                    <Grid.Column mobile={16} tablet={8} computer={8}>
                        <Form.Field>
                            <label>All prices inclusive</label>
                            <Radio toggle checked={allPricesInclusive} onChange={() => setAllPricesInclusive(!allPricesInclusive)}/>
                        </Form.Field>
                    </Grid.Column>
                    {propertyTypeProps === "Apartment" &&
                        <Grid.Column mobile={16} tablet={8} computer={8}>
                            <Form.Field required>
                                <label>Maintenance</label>
                                <Input icon='rupee sign' iconPosition='left' value={maintenanceCharges}
                                    action={
                                        <Dropdown button basic floating options={maintenance} defaultValue='Monthly'/>
                                    }
                                    placeholder='Maintenance' type="number"
                                    onChange={(event) => setMaintenanceCharges(event.target.value)}
                                />
                                {maintenanceCharges === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                            </Form.Field>
                        </Grid.Column>
                    }
                    {propertyTypeProps !== "Land" &&
                        <Grid.Column mobile={16} tablet={8} computer={8}>
                            <Form.Field>
                                <label>Expected Rental</label>
                                <Input icon='rupee sign' iconPosition='left' placeholder='Expected Rental' type="number"
                                       value={expectedRental} onChange={(event) => setExpectedRental(event.target.value)}/>
                            </Form.Field>
                        </Grid.Column>
                    }
                    {youAreProps === "Broker" &&
                    <Grid.Column mobile={16} tablet={8} computer={8}>
                        <Form.Field required>
                            <label>Brokerage (%)</label>
                            <Input value={brokerage} placeholder='Brokerage'
                                action={
                                    <Dropdown button basic floating options={negotiableOptions} defaultValue='Negotiable' />
                                }
                                type="number" min="0" icon='percent' iconPosition='left'
                                onChange={(event) => setBrokerage(event.target.value)}
                            />
                            {brokerage === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_INPUT}</Label>}
                        </Form.Field>                        
                    </Grid.Column>
                    }
            </Grid>
            <br/><br/>
            <Button.Group size="big" widths='2'>
                <Button basic icon color="blue" labelPosition="lft" onClick={() => setStep(3)}>Previous<Icon name='left arrow' /></Button>
                <Button icon color="blue" labelPosition="right" onClick={() => {pricingValid && setStep(5)}}>Next<Icon name='right arrow' /></Button>
            </Button.Group>
            <br/><br/>
        </Form>
    )
}

export default Pricing;
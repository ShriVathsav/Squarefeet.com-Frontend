import React,{useState,useEffect} from 'react';
import {Form, Dropdown, Button, Icon, Header, Label, DropdownItem, Grid} from 'semantic-ui-react';

const ERROR_MESSAGE_INPUT = "This field is mandatory"
const ERROR_MESSAGE_DROPDOWN = "Please select a value"

const Location = (props) => {

    const [step, setStep] = props.step

    const {houseNoProp, streetNameProp, localityProp, cityProp, landmarkProp, projectNameProp, locationValidProp} = props

    const [houseNo, setHouseNo] = houseNoProp
    const [streetName, setStreetName] = streetNameProp
    const [locality, setLocality] = localityProp
    const [city, setCity] = cityProp
    const [landmark, setLandmark] = landmarkProp
    const [projectName, setProjectName] = projectNameProp
    const [locationValid, setLocationValid] = locationValidProp;

    useEffect(() => console.log(houseNo, streetName, locality, city));

    const countryOptions = [
        { key: 'af', value: 'af', flag: 'af', text: 'Afghanistan' },
        { key: 'ax', value: 'ax', flag: 'ax', text: 'Aland Islands' },
        { key: 'al', value: 'al', flag: 'al', text: 'Albania' },
        { key: 'dz', value: 'dz', flag: 'dz', text: 'Algeria' },
        { key: 'as', value: 'as', flag: 'as', text: 'American Samoa' },
        { key: 'ad', value: 'ad', flag: 'ad', text: 'Andorra' },
        { key: 'ao', value: 'ao', flag: 'ao', text: 'Angola' },
        { key: 'ai', value: 'ai', flag: 'ai', text: 'Anguilla' },
        { key: 'ag', value: 'ag', flag: 'ag', text: 'Antigua' },
        { key: 'ar', value: 'ar', flag: 'ar', text: 'Argentina' },
        { key: 'am', value: 'am', flag: 'am', text: 'Armenia' },
        { key: 'aw', value: 'aw', flag: 'aw', text: 'Aruba' },
        { key: 'au', value: 'au', flag: 'au', text: 'Australia' },
        { key: 'at', value: 'at', flag: 'at', text: 'Austria' },
        { key: 'az', value: 'az', flag: 'az', text: 'Azerbaijan' },
        { key: 'bs', value: 'bs', flag: 'bs', text: 'Bahamas' },
        { key: 'bh', value: 'bh', flag: 'bh', text: 'Bahrain' },
        { key: 'bd', value: 'bd', flag: 'bd', text: 'Bangladesh' },
        { key: 'bb', value: 'bb', flag: 'bb', text: 'Barbados' },
        { key: 'by', value: 'by', flag: 'by', text: 'Belarus' },
        { key: 'be', value: 'be', flag: 'be', text: 'Belgium' },
        { key: 'bz', value: 'bz', flag: 'bz', text: 'Belize' },
        { key: 'bj', value: 'bj', flag: 'bj', text: 'Benin' },
    ]

    const formValid = () => {
        const valid = streetName !== "" && locality !== "" && city !== ""
        setLocationValid(valid)
    }

    useEffect(() => formValid())

    return(
        <Form>
            <Header as='h2' textAlign="center">
                <Header.Content>Location</Header.Content>
                <Header.Subheader>Fill in necessary location details</Header.Subheader>
            </Header>
            <Grid>
                <Grid.Column mobile={16} tablet={16} computer={16}>
                    <Form.Field>
                        <label>Street Name</label>
                        <input placeholder='Street Name' value={streetName}
                            onChange={(event) => setStreetName(event.target.value.trim())}/>
                        {streetName === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_INPUT}</Label>}
                    </Form.Field>
                </Grid.Column>
                <Grid.Column mobile={16} tablet={8} computer={8}>
                    <Form.Field>
                        <label>House No.</label>
                        <input placeholder='House No.' value={houseNo}
                            onChange={(event) => setHouseNo(event.target.value.trim())}/>
                    </Form.Field>
                </Grid.Column>
                <Grid.Column mobile={16} tablet={8} computer={8}>
                    <Form.Field>
                        <label>Landmark</label>
                        <input placeholder='Landmark' value={landmark}
                            onChange={(event) => setLandmark(event.target.value.trim())}/>
                    </Form.Field>
                </Grid.Column>
                <Grid.Column mobile={16} tablet={8} computer={8}>
                    <Form.Field required>
                        <label>Locality</label>
                        <input placeholder='Locality'  value={locality}
                            onChange={(event) => setLocality(event.target.value.trim())}/>
                        {locality === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_INPUT}</Label>}
                    </Form.Field>
                </Grid.Column>
                <Grid.Column mobile={16} tablet={8} computer={8}>
                    <Form.Field required>
                        <label>Project Name</label>
                        <input placeholder='Project Name' value={projectName}
                            onChange={(event) => setProjectName(event.target.value.trim())}/>
                        {projectName === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_INPUT}</Label>}
                    </Form.Field>
                </Grid.Column>
                <Grid.Column mobile={16} tablet={16} computer={16}>
                    <Form.Field required>
                        <label>City</label>
                        <Dropdown fluid search selection placeholder='Select City' value={city} 
                            options={countryOptions} onChange={(event, data) => setCity(data.value)}
                        />
                        {city === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                    </Form.Field>
                </Grid.Column>
            </Grid>
            <br/><br/>
            <Button.Group size="big" widths='2'>
                <Button basic icon color="blue" labelPosition="lft" onClick={() => setStep(1)}>Previous<Icon name='left arrow' /></Button>
                <Button icon color="blue" labelPosition="right" onClick={() => {locationValid && setStep(3)}}>Next<Icon name='right arrow' /></Button>
            </Button.Group>
            <br/><br/>
        </Form>
    )
}

export default Location;
import React,{useState, useEffect, Fragment} from 'react';
import {Input, Form, Dropdown, Grid, Radio, Button, Icon, Header, Image, Label} from 'semantic-ui-react';

import airConditioner from '../../FurnishingIcons/airConditioner.svg'
import bulb from '../../FurnishingIcons/bulb.svg'
import bed from '../../FurnishingIcons/bed.svg'
import cupBoard from '../../FurnishingIcons/cupboard.svg'
import curtain from '../../FurnishingIcons/curtain.svg'
import diningTable from '../../FurnishingIcons/dinner.svg'
import fan from '../../FurnishingIcons/fan.svg'
import modularKitchen from '../../FurnishingIcons/modularKitchen.svg'
import oven from '../../FurnishingIcons/oven.svg'
import refrigerator from '../../FurnishingIcons/refrigerator.svg'
import sofa from '../../FurnishingIcons/sofa.svg'
import stove from '../../FurnishingIcons/stove.svg'
import television from '../../FurnishingIcons/television.svg'
import wardrobe from '../../FurnishingIcons/wardrobe.svg'
import washingMachine from '../../FurnishingIcons/washing-machine.svg'
import waterHeater from '../../FurnishingIcons/waterHeater.svg'

const ERROR_MESSAGE_INPUT = "This field is mandatory"
const ERROR_MESSAGE_DROPDOWN = "Please select a value"
const ERROR_MESSAGE_FURNISHING_SEMI = "Select atleast 3 furnishings"
const ERROR_MESSAGE_FURNISHING_FULL = "Select atleast 5 furnishings"


const options = [
    { key: 'm', text: 'sq.ft.', value: 'sq.ft.' },
    { key: 'f', text: 'sq.m.', value: 'sq.m.' },
    { key: 'o', text: 'sq.yards', value: 'sq.yards' },
    { key: 'b', text: 'acres', value: 'acres' },
    { key: 'c', text: 'hectares', value: 'hectares' }
];

const furnishing = [
    { key: 'm', text: 'Furnished', value: 'Furnished' },
    { key: 'f', text: 'SemiFurnished', value: 'SemiFurnished' },
    { key: 'o', text: 'Unfurnished', value: 'Unfurnished' }
];

const carParking = [
    { key: 'z', text: '0', value: '0' },
    { key: 'm', text: '1', value: '1' },
    { key: 'f', text: '2', value: '2' },
    { key: 'o', text: '3', value: '3' },
    { key: 'a', text: '4', value: '4' },
    { key: 'i', text: '4+', value: '4+' }
];

const ageOfProperty = [
    { key: 'm', text: '0-1 year old property', value: '0-1 year old property' },
    { key: 'f', text: '1-5 years old property', value: '1-5 years old property' },
    { key: 'o', text: '5-10 years old property', value: '5-10 years old property' },
    { key: 'b', text: '10+ years old property', value: '10+ years old property' }
];

const addOtherRooms = [
    { key: 'm', text: 'Pooja Room', value: 'Pooja Room' },
    { key: 'f', text: 'Study Room', value: 'Study Room' },
    { key: 'o', text: 'Guest Room', value: 'Guest Room' },
    { key: 's', text: 'Servant Room', value: 'Servant Room' },
    { key: 't', text: 'Service Area', value: 'Service Area' }
];

const rooms = [
    { key: 'a', text: '0', value: '0' },
    { key: 'm', text: '1', value: '1' },
    { key: 'f', text: '2', value: '2' },
    { key: 'o', text: '3', value: '3' },
    { key: 's', text: '4', value: '4' },
    { key: 't', text: '4+', value: '4+' }
];

const availabilityList = [
    { key: 'm', text: 'Resale', value: 'Resale' },
    { key: 'f', text: 'Under Construction', value: 'Under Construction' }
];

const possessionByList = [
    { key: 'a', text: 'Within 3 months', value: 'Within 3 months' },
    { key: 'b', text: 'Within 6 months', value: 'Within 6 months' },
    { key: 'c', text: 'Within a year', value: 'Within a year' },
    { key: 'd', text: 'Within 2 years', value: 'Within 2 years' },
    { key: 'e', text: 'Within 3 years', value: 'Within 3 years' },
    { key: 'f', text: 'Within 4 years', value: 'Within 4 years' },
    { key: 'g', text: 'Within 5 years', value: 'Within 5 years' }
];


const PropertyDetails = (props) => {

    const [step, setStep] = props.step

    const [propertyOnFloorList, setPropertyOnFloorList] = useState([]);
    const [totalFloorList, setTotalFloorList] = useState([]);

    //  DESTRUCTURING PROPS
    const {superBuiltUpAreaProp, builtUpAreaProp, carpetAreaProp, bedroomsProp, bathroomsProp, propertyDetailsValidProp,
        balconiesProp, otherRoomsProp, furnishingDetProp, furnishingItemsProp,  totalFloorProp, propertyOnFloorProp, reservedParkingProp,
        closedParkingProp, openParkingProp, propertyAgeProp, availabilityProp, possessionByProp, undividedShareProp,
        numberOfFlatsProp, elevatorProp, plotAreaProp, floorsAllowedProp, propertyTypeProps, listPropertyForProps} = props;

    const [superBuiltUpArea, setSuperBuiltUpArea] = superBuiltUpAreaProp;
    const [builtUpArea, setBuiltUpArea] = builtUpAreaProp;
    const [carpetArea, setCarpetArea] = carpetAreaProp;
    const [bedrooms, setBedrooms] = bedroomsProp;
    const [bathrooms, setBathrooms] = bathroomsProp;
    const [balconies, setBalconies] = balconiesProp;
    const [otherRooms, setOtherRooms] = otherRoomsProp;
    const [furnishingDet, setFurnishingDet] = furnishingDetProp;
    const [furnishingItems, setFurnishingItems] = furnishingItemsProp;
    const [totalFloor, setTotalFloor] = totalFloorProp;
    const [propertyOnFloor, setPropertyOnFloor] = propertyOnFloorProp;
    const [reservedParking, setReservedParking] = reservedParkingProp;
    const [closedParking, setClosedParking] = closedParkingProp;
    const [openParking, setOpenParking] = openParkingProp;
    const [propertyAge, setPropertyAge] = propertyAgeProp;
    const [availability, setAvailability] = availabilityProp;
    const [possessionBy, setPossessionBy] = possessionByProp;
    const [undividedShare, setUndividedShare] = undividedShareProp;
    const [numberOfFlats, setNumberOfFlats] = numberOfFlatsProp;
    const [elevator, setElevator] = elevatorProp;
    const [plotArea, setPlotArea] = plotAreaProp;
    const [floorsAllowed, setFloorsAllowed] = floorsAllowedProp;
    const [propertyDetailsValid, setPropertyDetailsValid] = propertyDetailsValidProp;

    //useEffect(() => console.log(superBuiltUpArea, builtUpArea, carpetArea, bedrooms, bathrooms, balconies, otherRooms,
      //  furnishingDet, totalFloor, propertyOnFloor, reservedParking, closedParking, openParking, propertyAge));

    
    const formValid = () => {
        let valid
        if(propertyTypeProps === "Apartment" || propertyTypeProps === "House") {
            valid =  (superBuiltUpArea !== "" && carpetArea !== "" && bedrooms !== "" && bathrooms !== "" && bathrooms !== "" && furnishingDet !== "" &&
                totalFloor !== "" && (propertyTypeProps === "Apartment" ? propertyOnFloor !== "" : true) && (availability !== "" && ((availability === "Resale" && propertyAge !== "") || (availability === "Under Construction" && possessionBy !== ""))) && 
                (reservedParking === false ? true : ((closedParking !== "" && openParking !== "") && (closedParking !== "0" || openParking !== "0")))) ? true : false
        }
        else if(propertyTypeProps === "Land"){
            valid = plotArea !== "" && possessionBy !== "" && floorsAllowed !== ""
        }
        setPropertyDetailsValid(valid)
    }

    const calculateFloors = (max, floors = []) => {
        for (let i = 0; i <= max; i++) {
            floors.push({ key: i, text: i, value: i })
        }
        return floors;
    }

    const furnishingItemsValid = () => {
        let count = 0
        for (const item of furnishingItems){
            if(item.active === true){
                count += 1
                console.log(count, "count")
            }
        }
        if(furnishingDet === "Furnished"){
            return count < 5 ? true : false
        } else if (furnishingDet === "SemiFurnished"){
            return count < 3 ? true : false
        }
    }

    const addOrRemoveFurnishings = (entity, value = 0) => {
        setFurnishingItems(prev => {
            return [...prev].map(item => {
                let val
                if(entity.type === "input"){
                    val = {number: item.number + value, active: item.number + value !== 0}
                }else{
                    val = {active: !item.active}
                }
                return (item.id !== entity.id) ? {...item} : {...item, ...val}
            })            
        })
    }

    useEffect(() => console.log(furnishingItems), [furnishingItems])

    useEffect(() => {
        setTotalFloorList(calculateFloors(40));
        const furnishingItemsList = [
            {id: 0, icon: airConditioner, label: "Air Conditioner", type: "input", number: 0, active: false},
            {id: 1, icon: bulb, label: "Lights", type: "input", number: 0},
            {id: 2, icon: bed, label: "Bed", type: "input", number: 0},
            {id: 3, icon: cupBoard, label: "Cupboard", type: "input", number: 0},
            {id: 4, icon: curtain, label: "Curtains", type: "toggle", active: false},
            {id: 5, icon: diningTable, label: "Dining Table", type: "toggle", active: false},
            {id: 6, icon: fan, label: "Fan", type: "input", number: 0},
            {id: 7, icon: modularKitchen, label: "Modular Kitchen", type: "toggle", active: false},
            {id: 9, icon: oven, label: "Microwave", type: "toggle", active: false},
            {id: 10, icon: refrigerator, label: "Refrigerator", type: "toggle", active: false},
            {id: 11, icon: sofa, label: "Sofa/Couch", type: "toggle", active: false},
            {id: 12, icon: stove, label: "Stove", type: "toggle", active: false},
            {id: 13, icon: television, label: "Television", type: "input", number: 0},
            {id: 14, icon: wardrobe, label: "Wardrobe", type: "input", number: 0},
            {id: 15, icon: washingMachine, label: "Washing Machine", type: "toggle", active: false},
            {id: 16, icon: waterHeater, label: "Water Heater", type: "input", number: 0},
        ]
        setFurnishingItems(furnishingItemsList)
    }, []);

    useEffect(() => {
        setPropertyOnFloorList(calculateFloors(totalFloor));
    }, [totalFloor]);

    useEffect(() => formValid())

    return(
        <Form>
            <Header as='h2' textAlign="center">
                <Header.Content>Property Details</Header.Content>
                <Header.Subheader>Fill in all details so that your property gets discovered more.</Header.Subheader>
            </Header>
            <Grid>
                <Grid.Row></Grid.Row>
                <Grid.Row>
                    <Grid.Column>
                        <Header as='h5' dividing>
                            Area Details
                        </Header>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
            {propertyTypeProps !== "Land" ?
            <Grid>
                <Grid.Row>
                <Grid.Column mobile={16} tablet={8} computer={8}>
                    <Form.Field required>
                        <label>Super BuiltUp Area</label>
                        <Input value={superBuiltUpArea} placeholder='Super BuiltUp Area'
                            action={
                                <Dropdown button basic floating options={options} defaultValue='sq.ft.' />
                            }
                            type="number" min="0"
                            onChange={(event) => setSuperBuiltUpArea(event.target.value)}
                        />
                        {superBuiltUpArea === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_INPUT}</Label>}
                    </Form.Field>
                </Grid.Column>
                {(propertyTypeProps === "Apartment" && listPropertyForProps === "Sale") &&
                <Grid.Column mobile={16} tablet={8} computer={8}>
                    <Form.Field>
                        <label>Undivided Share (UDS)</label>
                        <Input value={undividedShare} placeholder='Undivided Share' type="number"
                            action={
                                <Dropdown button basic floating options={options} defaultValue='sq.ft.'/>
                            }
                            onChange={(event) => setUndividedShare(event.target.value)}
                        />
                    </Form.Field>
                </Grid.Column>
                }
                </Grid.Row>
                <Grid.Row>
                <Grid.Column mobile={16} tablet={8} computer={8}>
                    <Form.Field>
                        <label>BuiltUp Area</label>
                        <Input value={builtUpArea} placeholder='BuiltUp Area' type="number"
                            action={
                                <Dropdown button basic floating options={options} defaultValue='sq.ft.' />
                            }                            
                            onChange={(event) => setBuiltUpArea(event.target.value)}
                        />
                    </Form.Field>
                </Grid.Column>
                <Grid.Column mobile={16} tablet={8} computer={8}>
                    <Form.Field required>
                        <label>Carpet Area</label>
                        <Input value={carpetArea} placeholder='Carpet Area' type="number"
                            action={
                                <Dropdown button basic floating options={options} defaultValue='sq.ft.' />
                            }
                            onChange={(event) => setCarpetArea(event.target.value)}
                        />
                        {carpetArea === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_INPUT}</Label>}
                    </Form.Field>
                </Grid.Column>
                </Grid.Row>
            </Grid>
                :
            <Grid>
                <Grid.Column mobile={16} tablet={8} computer={8}>
                    <Form.Field required>
                        <label>Plot Area</label>
                        <Input value={plotArea} placeholder='Plot Area' type="number"
                            action={
                                <Dropdown button basic floating options={options} defaultValue='sq.ft.'/>
                            }
                            onChange={(event) => setPlotArea(event.target.value)}
                        />
                        {plotArea === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_INPUT}</Label>}
                    </Form.Field>
                </Grid.Column>
            </Grid>
            }
            {propertyTypeProps !== "Land" &&
                <Fragment>
                    <Grid>
                        <Grid.Row></Grid.Row>
                        <Grid.Row>
                            <Grid.Column>
                                <Header as='h5' dividing>
                                    Configuration Details
                                </Header>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    <Grid stackable columns={3}>
                        <Grid.Column>
                            <Form.Field required>
                                <label>Bedrooms</label>
                                <Dropdown fluid selection value={bedrooms} options={rooms} placeholder='Select' 
                                    onChange={(event, data) => setBedrooms(data.value)}
                                />
                                {bedrooms === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                            </Form.Field>
                        </Grid.Column>
                        <Grid.Column>
                            <Form.Field required>
                                <label>Bathrooms</label>
                                <Dropdown fluid selection value={bathrooms} options={rooms} placeholder='Select'
                                    onChange={(event, data) => setBathrooms(data.value)}
                                />
                                {bathrooms === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                            </Form.Field>
                        </Grid.Column>
                        <Grid.Column>
                            <Form.Field required>
                                <label>Balconies</label>
                                <Dropdown fluid selection value={balconies} options={rooms}
                                    placeholder='Select' onChange={(event, data) => setBalconies(data.value)}
                                />
                                {balconies === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                            </Form.Field>
                        </Grid.Column>
                    </Grid>
                    <Grid>
                        <Grid.Column>
                            <Form.Field>
                                <label>Add other rooms</label>
                                <Dropdown placeholder='Add other rooms' fluid multiple selection options={addOtherRooms}
                                    value={otherRooms} onChange={(event, data) => setOtherRooms(data.value)}
                                />
                            </Form.Field>
                        </Grid.Column>
                    </Grid>
                    <Grid>
                        <Grid.Row></Grid.Row>
                        <Grid.Row>
                            <Grid.Column>
                                <Header as='h5' dividing>
                                    Furnishing Details
                                </Header>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    <Grid>
                        <Grid.Column mobile={16} tablet={8} computer={8}>
                            <Form.Field required>
                                <label>Furnishing Details</label>
                                <Dropdown fluid selection options={furnishing} value={furnishingDet}
                                    placeholder='Select' onChange={(event, data) => setFurnishingDet(data.value)}
                                />
                                {furnishingDet === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                            </Form.Field>
                        </Grid.Column>
                    </Grid>
                    {(furnishingDet === "Furnished" || furnishingDet === "SemiFurnished") &&
                    <Grid style={{paddingLeft: 20, paddingBottom: 20}}>
                        {furnishingItems.map(items => (
                            <Grid.Column mobile={8} tablet={8} computer={5} key={items.label} style={{padding: 3}} >
                                <div style={{border: "1px solid grey", width: "100%", height: "100%"}}>
                                <Grid>
                                    <Grid.Column width={4}>
                                        <Image src={items.icon} size="mini" 
                                            style={{display: "inline", margin: 10, width: 40}} />
                                    </Grid.Column>
                                    <Grid.Column width={6} verticalAlign="middle">
                                        <span>{items.label}</span>
                                    </Grid.Column>
                                    <Grid.Column width={6} verticalAlign="middle" floated="right">
                                        {items.type === "input" ?
                                        <span style={{verticalAlign: "middle"}}>
                                            <Icon name="plus circle" size="large" style={{cursor: "pointer"}} id="iconhover"
                                                onClick={() => addOrRemoveFurnishings(items, 1)}/>
                                                {items.number}
                                            <Icon name="minus circle" id="iconhover" style={{cursor: "pointer", marginLeft: "3.5px"}}
                                                size="large" onClick={() => items.number > 0 && addOrRemoveFurnishings(items, -1)}/>
                                        </span>
                                        :
                                        <Radio style={{float: "right", marginRight: 7}} toggle checked={items.active}
                                            onChange={() => addOrRemoveFurnishings(items)}/>
                                        }
                                    </Grid.Column>
                                </Grid>
                                </div>
                            </Grid.Column>
                        ))}
                    </Grid>
                    }
                    {furnishingItemsValid() && <Label basic color='red' pointing>
                        {furnishingDet === "Furnished" ? ERROR_MESSAGE_FURNISHING_FULL : ERROR_MESSAGE_FURNISHING_SEMI}</Label>}
                </Fragment>
            } 
            <Grid>
                <Grid.Row></Grid.Row>
                <Grid.Row>
                    <Grid.Column>
                        <Header as='h5' dividing>
                            Floor Details
                        </Header>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
            {propertyTypeProps !== "Land" ?
            <Grid stackable columns={2}>
                <Grid.Column>
                    <Form.Field required>
                        <label>Total Floors</label>
                        <Dropdown fluid search selection placeholder='Select' value={totalFloor}
                            options={totalFloorList} onChange={(event, data) => setTotalFloor(data.value)}
                        />
                        {totalFloor === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                    </Form.Field>
                </Grid.Column>
                {propertyTypeProps === "Apartment" &&
                    <Grid.Column>
                        <Form.Field required>
                            <label>Property on Floor</label>
                            <Dropdown fluid search selection placeholder='Select' value={propertyOnFloor}
                                options={propertyOnFloorList} onChange={(event, data) => setPropertyOnFloor(data.value)}
                            />
                            {propertyOnFloor === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                        </Form.Field>
                    </Grid.Column>
                }
            </Grid>
            :
                <Grid>
                    <Grid.Column>
                        <Form.Field required>
                            <label>Floors allowed for Construction</label>
                            <Dropdown fluid search selection placeholder='Select' value={floorsAllowed} type="number"
                                options={totalFloorList} onChange={(event, data) => setFloorsAllowed(data.value)}
                            />
                        </Form.Field>
                    </Grid.Column>
                </Grid>
            }
            <Grid columns={2}>
                {propertyTypeProps === "Apartment" &&
                    <Grid.Column>
                        <Form.Field>
                            <label>Number of Flats</label>
                            <input placeholder='Number of Flats' value={numberOfFlats} type="number"
                                   onChange={(event) => setNumberOfFlats(event.target.value)}/>
                        </Form.Field>
                    </Grid.Column>
                }
                {propertyTypeProps !== "Land" &&
                <Grid.Column>
                    <Form.Field required>
                        <label>Presence of Elevator</label>
                    </Form.Field>
                    <Radio toggle checked={elevator} onChange={() => setElevator(!elevator)}/>
                </Grid.Column>
                }
            </Grid>
            {propertyTypeProps !== "Land" &&
                <Fragment>
            <Grid>
                <Grid.Row></Grid.Row>
                <Grid.Row>
                    <Grid.Column>
                        <Header as='h5' dividing>
                            Parking Details
                        </Header>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
            <Grid>
                <Grid.Column>
                    <Form.Field required>
                        <label>Do you have Reserved Parking?</label>
                    </Form.Field>
                    <Radio toggle checked={reservedParking} style={{display: "block"}} onChange={() => setReservedParking(!reservedParking)}/>
                    {(closedParking === "0" && openParking === "0") && <Label basic color='red' pointing>Please select atleast one parking feature</Label>}
                </Grid.Column>
            </Grid>
            {reservedParking &&
            <Grid stackable columns={2}>
                <Grid.Column>
                    <Form.Field required>
                        <label>Closed Parking</label>
                        <Dropdown fluid selection options={carParking} value={closedParking}
                            placeholder='Select' onChange={(event, data) => setClosedParking(data.value)}
                        />
                        {closedParking === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                    </Form.Field>
                </Grid.Column>
                <Grid.Column>
                    <Form.Field required>
                        <label>Open Parking</label>
                        <Dropdown fluid selection options={carParking} value={openParking}
                            placeholder='Select' onChange={(event, data) => setOpenParking(data.value)}
                        />
                        {openParking === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                    </Form.Field>
                </Grid.Column>
            </Grid>
            }
                </Fragment>
                }
            <Grid>
                {propertyTypeProps !== "Land" &&
                <Grid.Column mobile={16} tablet={8} computer={8}>
                    <Form.Field required>
                        <label>Availability</label>
                        <Dropdown fluid selection options={availabilityList} value={availability}
                            placeholder='Availability' onChange={(event, data) => setAvailability(data.value)}
                        />
                        {availability === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                    </Form.Field>
                </Grid.Column>
                }
                {availability === "Resale" &&
                <Grid.Column mobile={16} tablet={8} computer={8}>
                    <Form.Field required>
                        <label>Age of Property</label>
                        <Dropdown fluid selection options={ageOfProperty} placeholder='Age of Property'
                            value={propertyAge} onChange={(event, data) => setPropertyAge(data.value)}
                        />
                        {propertyAge === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                    </Form.Field>
                </Grid.Column>
                }
                {(availability === "Under Construction" || propertyTypeProps === "Land") &&
                    <Grid.Column mobile={16} tablet={8} computer={8}>
                        <Form.Field required>
                            <label>Possession By</label>
                            <Dropdown fluid selection options={possessionByList} value={possessionBy}
                                placeholder='Possession By' onChange={(event, data) => setPossessionBy(data.value)}
                            />
                            {possessionBy === "" && <Label basic color='red' pointing>{ERROR_MESSAGE_DROPDOWN}</Label>}
                        </Form.Field>
                    </Grid.Column>
                }
            </Grid>
            <br/><br/>
            <Button.Group size="big" widths='2'>
                <Button basic icon color="blue" labelPosition="left" onClick={() => setStep(2)}>Previous<Icon name='left arrow' /></Button>
                <Button icon color="blue" labelPosition="right" onClick={() => {propertyDetailsValid && setStep(4)}}>Next<Icon name='right arrow' /></Button>
            </Button.Group>
            <br/><br/>
        </Form>
    )
}

export default PropertyDetails;
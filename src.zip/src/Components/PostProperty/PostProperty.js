import React, { useState, Fragment, useEffect } from 'react';
import { Step, Grid, Segment, Header, Image, Icon } from 'semantic-ui-react';
import MainForm from './MainForm';
import CarouselTrial from "./CarouselTrial";

import basicDetails from '../Icons/StepIcons/basicdetails.svg'
import locationDetails from '../Icons/StepIcons/locationDetails.svg'
import propertyDetails from '../Icons/StepIcons/propertyDetails.svg'
import pricingDetails from '../Icons/StepIcons/pricingDetails.svg'
import features from '../Icons/StepIcons/features.svg'


const PostProperty = (props) => {

    const stepProps = useState(1);

    const basicDetailsValidProp = useState(false);
    const locationValidProp = useState(false);
    const propertyDetailsValidProp = useState(false);
    const pricingValidProp = useState(false);
    const featuresValidProp = useState(false);

    const [basicDetailsValid, setBasicDetailsValid] = basicDetailsValidProp
    const [locationValid, setLocationValid] = locationValidProp
    const [propertyDetailsValid, setPropertyDetailsValid] = propertyDetailsValidProp
    const [pricingValid, setPricingValid] = pricingValidProp
    const [featuresValid, setFeaturesValid] = featuresValidProp
    
    const [step, setStep] = stepProps

    useEffect(() => console.log(step, "STEP"), [step])

    const handleClick = (pest) => {
        console.log(pest, step, "HANDLE CLICK")
        switch(pest){
            case 1:
                console.log("case 1", step, setStep(1));setStep(1);
            case 2:
                basicDetailsValid && setStep(2);
            case 3:
                locationValid && setStep(3);
            case 4:
                propertyDetailsValid && setStep(4);
            case 5:
                pricingValid && setStep(5);
        }
        
    }

    const propsPassed = {stepProps, basicDetailsValidProp, locationValidProp, propertyDetailsValidProp, pricingValidProp ,featuresValidProp, handleClick}

    useEffect(() => {
        if(basicDetailsValid === false){
            setLocationValid(false)
        }
    }, [basicDetailsValid])

    useEffect(() => {
        if(locationValid === false){
            setPropertyDetailsValid(false)
        }
    }, [locationValid])

    useEffect(() => {
        if(propertyDetailsValid === false){
            setPricingValid(false)
        }
    }, [propertyDetailsValid])

    useEffect(() => {
        if(pricingValid === false){
            setFeaturesValid(false)
        }
    }, [pricingValid])

    const stack = () => {
        if (window.matchMedia("(max-width: 767px)").matches) {
            return true
        } else {
            return false
        }
    }    

    return (
        <Fragment>
            <Grid>
                <Grid.Column style={{}} mobile={16} tablet={5} computer={5} id="step-grid">
                    <Step.Group fluid vertical={!stack()} unstackable={stack()} id="mydiv">
                        <Step active={step === 1} link onClick={() => setStep(1)} id="step-item">
                            <Image src={basicDetails} size="mini" id="image"/>
                            <Step.Content>
                                <Step.Title id="step-title">Basic Details</Step.Title>
                            </Step.Content>
                        </Step>
                        <Step active={step === 2} link onClick={() => basicDetailsValid && setStep(2)} id="step-item" >
                            <Image src={locationDetails} size="mini" id="image"/>
                            <Step.Content>
                                <Step.Title id="step-title">Location</Step.Title>
                            </Step.Content>
                        </Step>
                        <Step active={step === 3} link onClick={() => locationValid && setStep(3)} id="step-item" >
                            <Image src={propertyDetails} size="mini" id="image"/>
                            <Step.Content style={{display: "flex", flexDirection: "row", flexFlow: "row wrap"}}>
                                <Step.Title id="step-title">Property Details</Step.Title>
                            </Step.Content>
                        </Step>
                        <Step active={step === 4} link onClick={() => propertyDetailsValid && setStep(4)} id="step-item">
                            <Image src={pricingDetails} id="image" />
                            <Step.Content>
                                <Step.Title id="step-title">Pricing</Step.Title>
                            </Step.Content>
                        </Step>
                        <Step active={step === 5} link onClick={() => pricingValid && setStep(5)} id="step-item">
                            <Image src={features} size="mini" id="image" />
                            <Step.Content>
                                <Step.Title id="step-title">Features</Step.Title>
                            </Step.Content>
                        </Step>
                    </Step.Group>
                </Grid.Column>
                <Grid.Column style={{}} mobile={16} tablet={11} computer={11} id="form-grid"> 
                    <Segment >
                        <MainForm {...propsPassed}/>
                    </Segment>
                </Grid.Column>
            </Grid>

            {/*<div className={"svg"}>
            <Logo/>
            </div>
            <CarouselTrial/>*/}

        </Fragment>
    )
}

export default PostProperty;